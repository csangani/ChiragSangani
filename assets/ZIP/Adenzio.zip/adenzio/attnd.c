/*

Attendance Register App file for Adenzio.

Developer: Chirag Sangani

*/

#include "includes.h"

void Attnd(void){adPrint("Attendance");}

void attnd(void)
{
	
	
	glcdInit();
	EEOpen();
	int atCount = 0;
	atCount = EEReadByte(1199);
	while(atCount<256)
	{
		glcdClearScreen();
		glcdHome();
		glcdRectangle(5,5,54,118);
		glcdSetAddress(22,2);
		adPrint("Enter Roll No.");
		glcdSetAddress(19,6);
		adPrint("x:Clear   Enter");
		glcdHome();
		glcdSetAddress(49,4);
		adPrint("Y");

		int atCharCount = 0;
		int atEscCount = 0;
		int atEscFlag = 0;
		char rollno[4];
		int j = 0;
		while(j<4)
		{	
			rollno[j]=' ';
			j++;
		}
		while (1)
		{
			char parseResult = parsePollResult(pollKeypad());
			if(parseResult=='`')
			{
				atEscCount++;
			}
			if(atEscCount == 6)
			{
				atEscFlag = 1;
				break;
			}

			if((parseResult<58)&(parseResult>46)&(atCharCount<4))
			{
				rollno[atCharCount] = parseResult;
				atCharCount++;
				glcdWriteChar(parseResult);
				
			}
			if(parseResult=='c')
			{
				int i =0;
				while(i<4){rollno[i]=0;i++;}
				atCharCount = 0;
			}
			if((parseResult=='\n')&(atCharCount==4))
			{
				int i=0;
				while(i<4)
				{
					EEWriteByte(1200+4*atCount+i,rollno[i]);
					i++;
				}
				i=0;
				while(i<4)
				{
					rollno[i]=EEReadByte(1200+4*atCount+i);
					i++;
				}
				glcdClearScreen();
				glcdHome();
				glcdRectangle(5,5,54,118);
				glcdSetAddress(22,2);
				adPrint("Record Success");
				glcdSetAddress(49,4);
				adPrint("Y");
				glcdWriteChar(rollno[0]);
				glcdWriteChar(rollno[1]);
				glcdWriteChar(rollno[2]);
				glcdWriteChar(rollno[3]);
				_delay_ms(3000);
				atCount++;
				break;
			}
			if(parseResult == 'x')
			{
				j = 0;
				while(j<4)
				{	
					rollno[j]=' ';
					j++;
				}
				glcdSetAddress(49,4);
				adPrint("Y    ");
				glcdSetAddress(49,4);
				adPrint("Y");
				atCharCount = 0;
			}

			_delay_ms(350);
		}

		if(atEscFlag){break;}
		EEWriteByte(1199, atCount);
	}

	glcdClearScreen();
	glcdHome();
	glcdRectangle(5,5,54,118);
	glcdSetAddress(31,2);
	adPrint("Record Full");
	glcdSetAddress(31,4);
	adPrint("t; Transmit");
	glcdSetAddress(40,5);
	adPrint("c: Clear");
	char parseResult;
	while(1)
	{
		parseResult = parsePollResult(pollKeypad());
		if((parseResult=='t')|(parseResult=='c')){break;}
	}
	if(parseResult=='c')
	{
		glcdHome();
		glcdClearScreen();
		glcdRectangle(20,5,54,88);
		glcdSetAddress(40,2);
		adPrint("CLEARING");
		glcdRectangle(38,30,11,52);
		glcdSetAddress(40,4);
		int i =0;
		while(i<257)
		{
			EEWriteByte(1199+i,0);
			i++;
			if(i%(257/48)==0){glcdDataWrite(0x7f);}
		}
		glcdInit();
	}
	if(parseResult=='t')
	{
		// Initialize USART

		UBRRL = BAUDUBRR;	// Set baud rate to 19200
		UBRRH = (BAUDUBRR>>8);
	
		/* Communication Parameters: (change as per your requirements)

		Asynchronous mode
		No Parity
		1 StopBit
		char size 8
		
		*/

		UCSRC = (1<<URSEL)|(3<<UCSZ0);

		//Enable the receiver and transmitter

		UCSRB = (1<<RXEN)|(1<<TXEN);

		glcdInit();
		glcdSetAddress(40,1);
		adPrint("Transmit");
		glcdSetAddress(46,2);
		adPrint("EEPROM");
		glcdSetAddress(49,4);
		adPrint("Enter");
		glcdRectangle(20,5,54,88);
		while((parsePollResult(pollKeypad())) !='\n');
		glcdHome();
		glcdClearScreen();
		glcdRectangle(20,5,54,88);
		glcdSetAddress(28,2);
		adPrint("TRANSMITTING");
		glcdRectangle(38,30,11,52);
		glcdSetAddress(40,4);
		int i =0;
		while(i<256)
		{
			while(!(UCSRA & (1<<UDRE)));
			UDR=EEReadByte(1200+i);
			i++;
			if(i%(256/48)==0){glcdDataWrite(0x7f);}
		}
		glcdInit();
	}
}




