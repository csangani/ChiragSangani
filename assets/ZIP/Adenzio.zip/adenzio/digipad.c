/*

Digipad App for Adenzio

Developer: Chirag Sangani

*/

#include "includes.h"

void DigiPad(void){adPrint("DigiPad");}

void digiapp(void)
{
	// Define variables
	
	char dpNoteText[NOTELENGTH];
	char dpScreenText[168];
	int dpCurChar;
	int pollResult;
	char parseResult;
	int dpCurInPage;
	int dpPageCount;
	int dpFlag;
	int dpCharacters;
	int dpCurScreen;
	int CursorState;
	int dpRefreshRequired;

	// Initialize timer for cursor

	TCCR1B |= ((1 << CS12) | (1 << CS10));

	// Perform specific boot-time operations

	glcdInit();
	EEOpen();

	dpRefreshRequired = 1;
	dpCurChar = 0;
	dpCharacters = 0;
	CursorState = 0;
	sysCursorBlink = 1;

	// Clean the note array

	int dpClearCounter = 0;
	while(dpClearCounter < NOTELENGTH)
	{
		dpNoteText[dpClearCounter]=0;
		dpClearCounter++;
	}

	// Welcome Screen

	glcdRectangle(5,5,54,118);
	glcdSetAddress(43,2);
	adPrint("DIGIPAD");
	glcdSetAddress(31,4);
	adPrint("For Adenzio");
	_delay_ms(3000);
	glcdInit();

	// Start the loop

	while(1)
	{
		// Refresh LCD if necessary

		initializeShift();
		if(dpRefreshRequired)
		{
			dpCurInPage = 0;
			dpPageCount = 0;
			dpFlag = 1;
			dpCurScreen = 0;
			int i;
			int j = 0;

			// Build pages till cursor is in current page

			while(dpFlag)
			{			
				i = 0;
				while(i < 168)
				{
					if((dpNoteText[j] != 0) & (dpNoteText[j] != '\n'))
					{
						dpScreenText[i] = dpNoteText[j];
						
					}
					else
					{
						dpScreenText[i] = ' ';
					}
					if(j == dpCurChar)
					{
						dpFlag = 0;
						dpCurScreen = i;
					}
					if(dpNoteText[j] == '\n')
					{
						int k = 0;
						for (k = 0; k < (21-(i%21)); k++)
						{
							dpScreenText[i+k] = ' ';
						}
						i += 20-(i%21);
					}
					i++;
					j++;
				}
				dpPageCount++;
			}

			// Display text and cursor

			glcdHome();
			glcdDataWrite(0x00);
			i = 0;
			while(i < 168)
			{
				glcdWriteChar(dpScreenText[i]);
				if(dpCurScreen == i)
				{
					/* Cursor Blinker

					First determine whether cursor blink is required.
					Then, toggle the state of the cursor.

					*/

					if (sysCursorBlink == 1)
    				{
						glcdSetAddress((glcdGetX()) - 7, glcdGetY());
						if(CursorState == 0)
						{	
							glcdDataWrite(0x7F);
							CursorState = 1;
						}
						else
						{
							glcdDataWrite(0x00);
							CursorState = 0;
						}
         				sysCursorBlink = 0;
						glcdSetAddress((glcdGetX()) +6, glcdGetY());
      				}
				}
				i++;
			}
			dpRefreshRequired=0;
		}

		if((TCNT1 >= 5850)&(CursorState == 0))
		{
			sysCursorBlink = 1;
		}

		if(sysCursorBlink == 1)
		{
			dpRefreshRequired = 1;
		}

		// Check keypad for pressed keys

		pollResult = pollKeypad();
		parseResult = parsePollResult(pollResult);
		if(pollResult != -1)
		{
			if((parseResult!=1)&(parseResult!=2)&(parseResult!=3)&(parseResult!=4)&(parseResult!=5)&(parseResult!=6)&(parseResult!=7)&(parseResult!=8)&(parseResult!=9))
			{
				if((dpCurChar==dpCharacters)&(dpCharacters < NOTELENGTH-1))
				{
					dpNoteText[dpCurChar] = parseResult;
					dpCurChar++;
					dpCharacters++;
					_delay_ms(KEYPADDELAY);
					dpRefreshRequired = 1;
				}
				else if((dpCurChar <= dpCharacters)&(dpCharacters < NOTELENGTH-1))
				{
					int i = NOTELENGTH - 2;
					while(i>=dpCurChar)
					{
						dpNoteText[i+1] = dpNoteText[i];
						i--;
					}
					dpNoteText[dpCurChar] = parseResult;
					dpCurChar++;
					dpCharacters++;
					_delay_ms(KEYPADDELAY);
					dpRefreshRequired = 1;
				}
			}
			else
			{
				
				// Save
				
				if(parseResult == 1)
				{
					glcdClearScreen();
					glcdHome();
					glcdRectangle(20,5,54,88);
					glcdSetAddress(51,1);
					adPrint("SAVE");
					glcdSetAddress(31,3);
					adPrint("Select Slot");
					glcdSetAddress(49,5);
					adPrint("1 2 3");
					parseResult = parsePollResult(pollKeypad());
					while(!((parseResult>48)&(parseResult<52))&(parseResult!='x'))
					{
						parseResult = parsePollResult(pollKeypad());
					}
					if(parseResult!='x')
					{
						glcdHome();
						glcdClearScreen();
						glcdRectangle(20,5,54,88);
						glcdSetAddress(40,2);
						adPrint("SAVING ");
						glcdWriteChar(parseResult);
						glcdRectangle(38,30,11,52);
						glcdSetAddress(40,4);
						int i = 0;
						while(i < NOTELENGTH)
						{
							DDRC = 0x00;
							PORTC = 0x00;
							EEWriteByte((parseResult-49)*NOTELENGTH+i,dpNoteText[i]);
							i++;
							if(i%(NOTELENGTH/48)==0){glcdDataWrite(0x7f);}
						}
						_delay_ms(300);
						glcdClearScreen();
						glcdHome();
						glcdRectangle(20,5,54,88);
						glcdSetAddress(49,3);
						adPrint("SAVED");
						_delay_ms(3000);
						dpRefreshRequired = 1;
					}
				}

				if(parseResult == 8)
				{
					glcdClearScreen();
					glcdHome();
					glcdRectangle(1,14,40,126);
					glcdSetAddress(5,3);
					adPrint("Please release SHIFT");
					glcdSetAddress(23,4);
					adPrint("before saving");
					_delay_ms(3000);
					dpRefreshRequired = 1;
				}

				// Load

				if(parseResult == 2)
				{
					glcdClearScreen();
					glcdHome();
					glcdRectangle(20,5,54,88);
					glcdSetAddress(51,1);
					adPrint("LOAD");
					glcdSetAddress(31,3);
					adPrint("Select Slot");
					glcdSetAddress(49,5);
					adPrint("1 2 3");
					parseResult = parsePollResult(pollKeypad());
					while(!((parseResult>48)&(parseResult<52))&(parseResult!='x'))
					{
						parseResult = parsePollResult(pollKeypad());
					}
					if(parseResult!='x')
					{
						glcdHome();
						glcdClearScreen();
						glcdRectangle(20,5,54,88);
						glcdSetAddress(37,2);
						adPrint("LOADING ");
						glcdWriteChar(parseResult);
						glcdRectangle(38,30,11,52);
						glcdSetAddress(40,4);
						int i = 0;
						dpCurChar = 0;
						while(i < NOTELENGTH)
						{
							DDRC = 0x00;
							PORTC = 0x00;
							dpNoteText[i] = EEReadByte((parseResult-49)*NOTELENGTH+i);
							if(dpNoteText[i]!=0){dpCurChar++;}
							i++;
							if(i%(NOTELENGTH/48)==0){glcdDataWrite(0x7f);}
						}
						_delay_ms(300);
						glcdClearScreen();
						glcdHome();
						glcdRectangle(20,5,54,88);
						glcdSetAddress(43,3);
						adPrint("SUCCESS");
						_delay_ms(3000);
						dpRefreshRequired = 1;
					}
				}

				if(parseResult == 9)
				{
					glcdClearScreen();
					glcdHome();
					glcdRectangle(1,14,40,126);
					glcdSetAddress(5,3);
					adPrint("Please release SHIFT");
					glcdSetAddress(20,4);
					adPrint("before loading");
					_delay_ms(3000);
					dpRefreshRequired = 1;
				}

				// Cursor Right

				if(parseResult == 4)
				{
					if(dpCurChar < dpCharacters){dpCurChar++;_delay_ms(KEYPADDELAY);}
				}

				// Cursor Left

				if(parseResult == 5)
				{
					if(dpCurChar != 0){dpCurChar = dpCurChar - 1;_delay_ms(KEYPADDELAY);}
				}

				// Cursor Up

				if(parseResult == 3)
				{
					if(dpCurChar != 0)
					{
						int i = 0;
						while(i<21)
						{
							dpCurChar-=1;
							i++;
							if((dpNoteText[dpCurChar] == '\n')|(dpCurChar == 0)){break;}
						}
						_delay_ms(KEYPADDELAY);
					}
				}

				// Cursor Down
				
				if(parseResult == 6)
				{
					if(dpCurChar != dpCharacters)
					{
						int i = 0;
						while(i<21)
						{
							if(dpCurChar == dpCharacters){break;}
							dpCurChar++;
							if(dpNoteText[dpCurChar] == '\n'){break;}
							i++;
						}
						_delay_ms(KEYPADDELAY);
					}
				}

				// Backspace

				if(parseResult == 7)
				{
					if(dpCurChar!= 0)
					{
						int i = dpCurChar;
						while(i<NOTELENGTH)
						{
							dpNoteText[i-1]=dpNoteText[i];
							i++;
						}
						dpCharacters-=1;
						dpCurChar-=1;
						_delay_ms(KEYPADDELAY);
					}
				}
			}
		}
	}
}
