/*

Terminal App file for Adenzio.

Developer: Chirag Sangani

*/

#include "includes.h"

void Terminal(void){adPrint("Terminal");}

void terminal(void)
{
	// Initialize variables

	char parseResult;
	int pollResult;
	int trCharCount = 0;
	int CursorState = 0;
	
	// Initialize USART

	UBRRL = BAUDUBRR;	// Set baud rate to 19200
	UBRRH = (BAUDUBRR>>8);


   /* Communication Parameters: (change as per your requirements)

    Asynchronous mode
    No Parity
    1 StopBit
    char size 8

   */

   UCSRC = (1<<URSEL)|(3<<UCSZ0);

	//Enable the receiver and transmitter

   UCSRB = (1<<RXEN)|(1<<TXEN);

	// Initialize timer for cursor

	TCCR1B |= ((1 << CS12) | (1 << CS10));

	// Start-up operations

	glcdInit();
	EEOpen();

	// Welcome Screen

	glcdRectangle(5,5,54,118);
	glcdSetAddress(40,2);
	adPrint("TERMINAL");
	glcdSetAddress(31,4);
	adPrint("For Adenzio");
	_delay_ms(3000);
	glcdInit();

	while(1)
	{
		if(UCSRA & (1<<RXC))
		{
			if(trCharCount == 168)
			{
				glcdClearScreen();
				glcdHome();
				trCharCount = 0;
			}
			glcdWriteChar(UDR);
			trCharCount++;
		}

		if(sysCursorBlink)
		{
			glcdSetAddress((glcdGetX()), glcdGetY());
			if(CursorState == 0)
			{	
				glcdDataWrite(0x7F);
				CursorState = 1;
			}
			else
			{
				glcdDataWrite(0x00);
				CursorState = 0;
			}
			glcdSetAddress((glcdGetX())-1, glcdGetY());
			sysCursorBlink = 0;
		}

		if((TCNT1 >= 5850)&(CursorState == 0))
		{
			sysCursorBlink = 1;
		}


		pollResult = pollKeypad();
		parseResult = parsePollResult(pollResult);
		if(pollResult!=-1)
		{
			if((parseResult!=1)&(parseResult!= 2)&(parseResult!= 3)&(parseResult!=4)&(parseResult!=5)&(parseResult!=6)&(parseResult!=7)&(parseResult!=8)&(parseResult!=9))
			{
				while(!(UCSRA & (1<<UDRE)));
				UDR=parseResult;
				if(trCharCount == 168)
				{
					glcdClearScreen();
					glcdHome();
					trCharCount = 0;
				}
				glcdWriteChar(parseResult);
				trCharCount++;
				_delay_ms(50);
			}
			else
			{
				if(parseResult == 1)
				{
					glcdInit();
					glcdSetAddress(40,1);
					adPrint("Transmit");
					glcdSetAddress(46,2);
					adPrint("EEPROM");
					glcdSetAddress(49,4);
					adPrint("Enter");
					glcdRectangle(20,5,54,88);
					while((parsePollResult(pollKeypad())) !='\n');
					glcdHome();
					glcdClearScreen();
					glcdRectangle(20,5,54,88);
					glcdSetAddress(28,2);
					adPrint("TRANSMITTING");
					glcdRectangle(38,30,11,52);
					glcdSetAddress(40,4);
					int i =0;
					while(i<8192)
					{
						while(!(UCSRA & (1<<UDRE)));
						UDR=EEReadByte(i);
						i++;
						if(i%(8192/48)==0){glcdDataWrite(0x7f);}
					}
					glcdInit();
				}
			}
		}
	}
}
