/*
The Adenzio C operating system.

Designed for general use on any C-capable microcontroller or SoC,
the main goal of Adenzio is to  enable developers to develop applications without
worrying about the platform. The interaction of the operating system with the hardware
is via drivers which provide standard APIs. Adenzio is free to use and open source
under the GPL license.

Developer: Chirag Sangani
*/

#include "includes.h"

// RTC Compare Interrupt
ISR(TIMER1_COMPB_vect)
{
	TCNT1 = TCNT1 - 11719;
	sysSec++;
	if(sysSec >= 60)
	{
		sysSec = 0;
		sysMin++;
	}
	if(sysMin >= 60)
	{
		sysMin = 0;
		sysHour++;
	}
	if(sysHour >= 24)
	{
		sysHour = 0;
		sysDay++;
	}
	if((sysMnth == 1)|(sysMnth == 3)|(sysMnth == 5)|(sysMnth == 7)|(sysMnth == 8)|(sysMnth == 10)|(sysMnth == 12))
	{
		if(sysDay >= 32)
		{
			sysDay = 1;
			sysMnth++;
		}
	}
	else if(sysMnth >= 2)
	{
		if((sysYear-2000)%4 == 0)
		{
			if(sysDay >= 30)
			{
				sysDay = 1;
				sysMnth++;
			}
		}
		else
		{
			if(sysDay >= 29)
			{
				sysDay = 1;
				sysMnth++;
			}
		}
	}
	else
	{
		if(sysDay >= 31)
		{
			sysDay = 1;
			sysMnth++;
		}
	}

	if(sysMnth >= 13)
	{
		sysMnth = 1;
		sysYear++;
	}
	sysTimeChange = 1;
	sysCursorBlink = 1;
}
// Start boot-time operations

int main(void)
{
	DDRB |= (1<<6);
	PORTB |= (1<<6);
	sysSec = 0;
	sysMin = 0;
	sysHour = 0;
	sysDay = 1;
	sysMnth = 1;
	sysYear = 2009;
	sysTimeChange = 1;

	// Initiate Timer1 and Timer1 Compare Match Interrupt

	OCR1B=11719;
	TIMSK |= (1<<OCIE1B);
	TCCR1B |= ((1 << CS12) | (1 << CS10) | (1<<WGM12));

	// Initialize LCD
	
	glcdInit();
	glcdClearScreen();

	// Initialize Variables

	int sysRefreshRequired = 1;

	while(1)
	{
		if(sysRefreshRequired)
		{
			glcdHome();
			glcdRectangle(0,8,56,127);
			glcdSetAddress(0,0);
			adPrint("s: Sleep");
			glcdSetAddress(62,0);
			if((sysDay/10)==0){glcdWriteChar(' ');}
			if((sysMnth/10)==0){glcdWriteChar(' ');}
			if((sysDay/10)!=0){glcdWriteChar(48+sysDay/10);}
			glcdWriteChar(48+sysDay%10);
			glcdWriteChar('/');
			if((sysDay/10)!=0){glcdWriteChar(48+sysMnth/10);}
			glcdWriteChar(48+sysMnth%10);
			glcdWriteChar(' ');
			glcdWriteChar(48+sysHour/10);
			glcdWriteChar(48+sysHour%10);
			glcdWriteChar(':');
			glcdWriteChar(48+sysMin/10);
			glcdWriteChar(48+sysMin%10);
		
			#ifdef APP1
			glcdHome();
			glcdSetAddress(10,3);
			adPrint("1. ");
			APP1NAME();
			#endif
			#ifdef APP2
			glcdHome();
			glcdSetAddress(10,4);
			adPrint("2. ");
			APP2NAME();
			#endif
			#ifdef APP3
			glcdHome();
			glcdSetAddress(10,5);
			adPrint("3. ");
			APP3NAME();
			#endif
			#ifdef APP4
			glcdHome();
			glcdSetAddress(10,6);
			adPrint("4. ");
			APP4NAME();
			#endif
			sysRefreshRequired = 0;
		}

		int sysPollResult = pollKeypad();
		char sysParseResult = parsePollResult(sysPollResult);

		if(sysPollResult != -1)
		{
			#ifdef APP1
			if(sysParseResult == '1'){APP1();}
			#endif
			#ifdef APP2
			if(sysParseResult == '2'){APP2();}
			#endif
			#ifdef APP3
			if(sysParseResult == '3'){APP3();}
			#endif
			#ifdef APP4
			if(sysParseResult == '4'){APP4();}
			#endif

			if(sysParseResult == 's')
			{
				_delay_ms(300);
				while(1)
				{
					glcdClearScreen();
					PORTB &= ~(1<<6);
					MCUCR |= ((1<<SM0)|(1<<SM1)|(1<<SM2)|(1<<SE));
					if(pollKeypad()!=-1){break;}
				}
				_delay_ms(300);
				PORTB |= (1<<6);
			}

			if(sysParseResult == 't')
			{
				glcdClearScreen();
				glcdHome();
				glcdRectangle(5,5,54,18);
				glcdSetAddress(40,1);
				adPrint("Set Time");
				glcdHome();
				glcdSetAddress(40,3);
				glcdWriteChar(48+sysHour/10);
				glcdWriteChar(48+sysHour%10);
				glcdWriteChar('/');
				glcdWriteChar(48+sysMin/10);
				glcdWriteChar(48+sysMin%10);
				glcdHome();
				glcdSetAddress(34,5);
				glcdWriteChar(48+sysDay/10);
				glcdWriteChar(48+sysDay%10);
				glcdWriteChar('/');
				glcdWriteChar(48+sysMnth/10);
				glcdWriteChar(48+sysMnth%10);
				glcdWriteChar('/');
				glcdWriteChar(48+sysYear/1000);
				glcdWriteChar(48+(sysYear%1000)/100);
				glcdWriteChar(48+(sysYear%100)/10);
				glcdWriteChar(48+sysYear%10);
				int sysCount=0;
				char tempParse;
				while(sysCount<12)
				{
					tempParse = parsePollResult(pollKeypad());
					if((tempParse>='0')&(tempParse<='9'))
					{
						switch(sysCount)
						{
							case 0: {	sysHour = (tempParse-48)*10;
										sysCount++;
										glcdHome();
										glcdSetAddress(40,3);
										glcdWriteChar(48+sysHour/10);
										break;
									}
							case 1: {	sysHour += (tempParse-48);
										sysCount++;
										glcdWriteChar(48+sysHour%10);
										glcdWriteChar(':');
										break;
									}
							case 2: {	sysMin = (tempParse-48)*10;
										sysCount++;
										glcdWriteChar(48+sysMin/10);
										break;
									}
							case 3: {	sysMin += (tempParse-48);
										sysCount++;
										glcdWriteChar(48+sysMin%10);
										break;
									}
							case 4: {	sysDay = (tempParse-48)*10;
										sysCount++;
										glcdSetAddress(34,5);
										glcdWriteChar(48+sysDay/10);
										break;
									}
							case 5: {	sysDay += (tempParse-48);
										sysCount++;
										glcdWriteChar(48+sysDay%10);
										glcdWriteChar('/');
										break;
									}
							case 6: {	sysMnth = (tempParse-48)*10;
										sysCount++;
										glcdSetAddress(34,5);
										glcdWriteChar(48+sysMnth/10);
										break;
									}
							case 7: {	sysMnth += (tempParse-48);
										sysCount++;
										glcdWriteChar(48+sysMnth%10);
										glcdWriteChar('/');
										break;
									}
							case 8: {	sysHour = (tempParse-48)*1000;
										sysCount++;
										glcdWriteChar(48+sysHour/1000);
										break;
									}
							case 9: {	sysHour += (tempParse-48)*100;
										sysCount++;
										glcdWriteChar(48+(sysHour%1000)/100);
										break;
									}
							case 10: {	sysHour += (tempParse-48)*10;
										sysCount++;
										glcdWriteChar(48+(sysHour%100)/10);
										break;
									}
							case 11: {	sysHour += (tempParse-48);
										sysCount++;
										glcdWriteChar(48+sysHour%1000);
										break;
									}
							default: break;
						}
					}
				}
			}
		}

		if(sysTimeChange ==1)
		{
			sysRefreshRequired = 1;
		}
	}
}
