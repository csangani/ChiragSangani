/*
The Adenzio C operating system.

Designed for general use on any C-capable microcontroller or SoC,
the main goal of Adenzio is to  enable developers to develp applications without
worrying about the platform. The interaction of the operating system with the hardware
is via drivers which provide standard APIs. Adenzio is free to use and open source
under the GPL license.

Developer: Chirag Sangani
*/

/*

Adenzio Header file
Declares Adenzio-specific variables and functions

*/

// Loading system files
// DO NOT DELETE THE FOLLOWING LINES

#ifndef AD_INC_H
#define AD_INC_H

// Define your CPU parameters
#ifndef F_CPU
#define F_CPU 12000000 // Clock Frequency
#endif
// DO NOT MODIFY BELOW

#ifndef F_CPU
#warning "CPU clock frequency not defined in the adenzio.h file"
#endif

int sysSec;
int sysMin;
int sysHour;
int sysDay;
int sysMnth;
int sysYear;
int sysCursorBlink;
int sysTimeChange;

#endif
