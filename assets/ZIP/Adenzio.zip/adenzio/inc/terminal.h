/*

Terminal App file for Adenzio.

Developer: Chirag Sangani

*/

#define APP2 terminal
#define APP2NAME Terminal

#define BAUDUBRR 77

void terminal(void);
void Terminal(void);
