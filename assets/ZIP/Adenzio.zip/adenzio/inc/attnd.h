/*

Attendance Register App file for Adenzio.

Developer: Chirag Sangani

*/

#define APP3 attnd
#define APP3NAME Attnd

void attnd(void);
void Attnd(void);
