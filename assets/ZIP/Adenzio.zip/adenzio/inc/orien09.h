/*

Orientation09 App file for Adenzio.

Developer: Chirag Sangani

*/

#define APP3 orien09
#define APP3NAME Orien09


void orien09(void);
void Orien09(void);
