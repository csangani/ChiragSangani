/*

Digipad App file for Adenzio.

Developer: Chirag Sangani

*/

#define APP1 digiapp
#define APP1NAME DigiPad

#define NOTELENGTH 336
#define KEYPADDELAY 350
void digiapp(void);
void DigiPad(void);
