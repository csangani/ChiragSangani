/*

Adenzio driver header file for the keypad of the Digital Notepad project.

*/

#include <avr/io.h>

#define KPPORT1 PORTC	// Connector 1 Port
#define KPDDR1 DDRC		// Connector 1 DDR
#define KPPIN1 PINC		// Connector 1 Pin
#define KPP1START 2		// Connector 1 Start Bit

#define KPPORT2 PORTD	// Connector 2 Port
#define KPDDR2 DDRD		// Connector 2 DDR
#define KPPIN2 PIND		// Connector 2 Pin
#define KPP2START 2		// Connector 2 Start Bit

#define SHIFTPORT PORTB	// Port where shift key is connected
#define SHIFTDDR DDRB
#define SHIFTPIN PINB
#define SHIFTBIT 5		// Bit value of port where shift is connected

// Poll the keypad to return key combination

int pollKeypad(void);

// Parse poll result for correct character

char parsePollResult(int input);

// Set Shift PORT Settings

void initializeShift(void);
