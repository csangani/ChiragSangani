/*
The Adenzio C operating system.

Designed for general use on any C-capable microcontroller or SoC,
the main goal of Adenzio is to  enable developers to develp applications without
worrying about the platform. The interaction of the operating system with the hardware
is via drivers which provide standard APIs. Adenzio is free to use and open source
under the GPL license.

Developer: Chirag Sangani
*/

// Adenzio System File. DO NOT MODIFY.

#include <inttypes.h>

uint8_t apps = 0;

int adApps[5];
char adAppName[5][5];
