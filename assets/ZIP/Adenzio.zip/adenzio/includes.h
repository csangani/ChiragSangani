/*
The Adenzio C operating system.

Designed for general use on any C-capable microcontroller or SoC,
the main goal of Adenzio is to  enable developers to develp applications without
worrying about the platform. The interaction of the operating system with the hardware
is via drivers which provide standard APIs. Adenzio is free to use and open source
under the GPL license.

Developer: Chirag Sangani
*/


// Adenzio include file - include your header files here and include this file in
// your source files.

// Load essential system files.
#ifndef ADENZIO
#define ADENZIO
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <inttypes.h>
#include "inc/global.h"
#include "inc/adenzio.h" //Configure this file as per your platform

// Load driver files.
// Add drivers as per your requirements.

#include "inc/ks0108.h"
#include "inc/ks0108conf.h"
#include "inc/keypad.h"
#include "inc/24c64.h"

// Load Graphical API.

#include "inc/glcd.h"

// Load other standard APIs as per your requirements
// UNCOMMENT ONLY IF REQUIRED

// #include <ctype.h>
// #include <math.h>
// #include <string.h>
// #include <stdio.h>
#include <util/delay.h>


// Application includes

#include "inc/digipad.h"
#include "inc/terminal.h"
#include "inc/orien09.h"

#endif
