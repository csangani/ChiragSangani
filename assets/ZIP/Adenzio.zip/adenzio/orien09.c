#include "includes.h"

void Orien09(void)
{
	adPrint("Orien09");
}

void orien09(void)
{
	glcdInit();
	glcdSetAddress(18,3);
	adPrint("Electronics Club");
	glcdNewLine();
	while(1)
	{
		glcdSetAddress(36,5);
		adPrint("IIT Kanpur");
		glcdNewLine();
		_delay_ms(1000);
		glcdClearScreen();
		glcdNewLine();
		glcdSetAddress(18,3);
		adPrint("Electronics Club");
		glcdNewLine();
		_delay_ms(1000);
	}
}
