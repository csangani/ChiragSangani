#include "corsiva_12.h"
#include "arial_bold_14.h"
#include "ks0108.h"


int main(void)
{
	// Wait a little while the display starts up
	for(volatile uint16_t i=0; i<15000; i++);
	
	// Initialize the LCD
	ks0108Init(0);
	
	// Select a font
	ks0108SelectFont(Arial_Bold_14, ks0108ReadFontData, BLACK);
	// Set a position
	ks0108GotoXY(0,0);
	// Print some text
	ks0108Puts_P(PSTR("Elektrorockers!"));
	while(1)
	{ };

}
