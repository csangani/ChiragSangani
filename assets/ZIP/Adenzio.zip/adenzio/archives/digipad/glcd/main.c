#include <avr/io.h>
#include <string.h>
#include "global.h"
#include "ks0108.h"
#include "glcd.h"
#include "util/delay.h"

int screenRefreshRequired = 0;
int pollResult = -1;
int sourcePin = 0, sinkPin = 0;
char parseResult = ' ';
char noteText[512];
int characters = 0;

void assembleScreenDisplay(void)
{
	if(characters==0)
	{
		glcdHome();
		for(volatile int i = 0; i<168; i++)
		{
			glcdWriteChar(' ');
		}
	}
	else if(characters%168==0)
	{
		glcdHome();
		for(volatile int i = 0; i<168; i++)
		{
			glcdWriteChar(noteText[characters-168+i]);
		}
	}
	else
	{
		glcdHome();
		for(volatile int i = 0; i<(characters%168); i++)
		{
			glcdWriteChar(noteText[characters-(characters%168)+i]);
		}
		for(volatile int i=0; i<(168-(characters%168)); i++)
		{
			glcdWriteChar(' ');
		}
	}
}
			

int pollKeypad(void)
{
	for(sourcePin = 2; sourcePin < 8; sourcePin++)
	{
		DDRC = (1<<sourcePin);
		PORTC = ~DDRC;
		PORTD = 0xff;
		for(sinkPin = sourcePin + 1; sinkPin < 8; sinkPin++)
		{
			if(((PINC&(1<<sinkPin))>>sinkPin)==0)
			{
				return (1000+100*sourcePin+10+sinkPin);
			}
		}
		for(sinkPin = 2; sinkPin < 8; sinkPin++)
		{
			if(((PIND&(1<<sinkPin))>>sinkPin)==0)
			{
				return (1000+100*sourcePin+20+sinkPin);
			}
		}
	}
	for(sourcePin = 2; sourcePin < 7; sourcePin++)
	{
		DDRD = (1<<sourcePin);
		PORTD=~DDRD;
		for(sinkPin = sourcePin + 1; sinkPin < 8; sinkPin++)
		{
			if(((PIND&(1<<sinkPin))>>sinkPin)==0)
			{
				return (2000+100*sourcePin+20+sinkPin);
			}
		}
	}
	return -1;
}

char parsePollResult(int input)
{
	switch(input)
	{
		case 1213: return '-';
		case 1214: return 'z';
		case 1215: return 'd';
		case 1216: return 'r';
		case 1217: return '4';
		case 1222: return '/';
		case 1223: return '.';
		case 1224: return ',';
		case 1225: return '\n';
		case 1226: return ' ';
		case 1227: return ';';
		case 1314: return '-';
		case 1315: return 's';
		case 1316: return 'e';
		case 1317: return '3';
		case 1322: return '|';
		case 1323: return ']';
		case 1324: return '[';
		case 1325: return 'u';
		case 1326: return 'y';
		case 1327: return '=';
		case 1415: return 'a';
		case 1416: return 'w';
		case 1417: return '2';
		case 1422: return 'm';
		case 1423: return 'n';
		case 1424: return 'b';
		case 1425: return 'v';
		case 1426: return 'd';
		case 1427: return 'x';
		case 1516: return 'q';
		case 1517: return '1';
		case 1522: return 'l';
		case 1523: return 'k';
		case 1524: return 'j';
		case 1525: return 'h';
		case 1526: return 'g';
		case 1527: return 'f';
		case 1617: return '`';
		case 1622: return 'p';
		case 1623: return 'o';
		case 1624: return 'i';
		case 1625: return 'u';
		case 1626: return 'y';
		case 1627: return 't';
		case 1722: return '0';
		case 1723: return '9';
		case 1724: return '8';
		case 1725: return '7';
		case 1726: return '6';
		case 1727: return '5';
		case 2223: return 'U';
		case 2224: return 'I';
		case 2225: return 'O';
		case 2226: return '6';
		case 2227: return 'A';
		case 2324: return 'S';
		case 2325: return 'D';
		case 2326: return '6';
		case 2327: return 'G';
		case 2425: return 'H';
		case 2426: return '6';
		case 2427: return ' ';
		case 2526: return '6';
		case 2527: return 'Z';
		case 2627: return 'X';
		default: return -1;
	}
}


void screenRefresh(int newChar)
{
	noteText[characters] = newChar;
	characters++;
	assembleScreenDisplay();
	screenRefreshRequired=0;
	_delay_ms(15);
}

int main(void){
	glcdInit();
	// Screen refresh
	while(1){
		if(screenRefreshRequired)
		{
			screenRefresh(parseResult);
		}

		pollResult = pollKeypad();
		if(pollResult != -1)
		{
			parseResult = parsePollResult(pollResult);
			screenRefreshRequired = 1;
		}
	}
}
