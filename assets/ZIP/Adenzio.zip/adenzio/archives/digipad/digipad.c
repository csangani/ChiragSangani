#include <inttypes.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include "util/delay.h"

#include "ks0108.h"
#include "arial_bold_14.h"
#include "corsiva_12.h"

int main(void) {
	
	// Wait a little while the display starts up
	for(volatile uint16_t i=0; i<30000; i++);

	
	// Initialize the LCD
	ks0108Init(0);
	
	// Select a font
	ks0108SelectFont(Arial_Bold_14, ks0108ReadFontData, BLACK);
	// Set a position
	ks0108GotoXY(12,10);
	// Print some text
	ks0108Puts("Electronics Club");
	
	while(1){
		ks0108GotoXY(35, 30);
		ks0108Puts("IIT Kanpur");
		_delay_ms(30);
		ks0108FillRect(0, 30, 127, 33, WHITE);
		_delay_ms(30);
	}
}
