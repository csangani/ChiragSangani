#include <avr/io.h>
#include "util/delay.h"
#include "24c64.h"
int main (void)
{
}
