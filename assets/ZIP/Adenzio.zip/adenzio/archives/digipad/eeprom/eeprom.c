#include <inttypes.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "24c64.h"
int mode = 0;
int i = 0;
int read;
unsigned int address = 0;
int main (void)
{
	
	read = EEReadByte(address);
	if(read!=0)
	{
		DDRD = 0xff;
		PORTD = (1<<read);
	}
	DDRA = 0x00;
	while((PINA&0b00000011)==0b00000000);
	if((PINA&0x01)==0x01)
	{
		EEWriteByte(address,1);
	}
	else
	{
		EEWriteByte(address,2);
	}
	read = EEReadByte(address);
	if(read!=0)
	{
		DDRD = 0xff;
		PORTD = (1<<read);
	}
}


	

