/*

Adenzio driver source file for the keypad of the Digital Notepad project.

*/

#include "inc/keypad.h"



int pollKeypad(void)
{
	int sourcePin, sinkPin, shift = 1;
	if(((SHIFTPIN&(1<<SHIFTBIT))>>SHIFTBIT)==0)
	{
		shift = 2;
	}
	
	for(sourcePin = KPP1START; sourcePin < (KPP1START + 6); sourcePin++)
	{
		KPDDR1 = (1<<sourcePin);
		KPDDR2 = 0x00;
		KPPORT1 = ~KPDDR1;
		KPPORT2 = 0xff;
		for(sinkPin = sourcePin + 1; sinkPin < (KPP1START + 6); sinkPin++)
		{
			if(((KPPIN1&(1<<sinkPin))>>sinkPin)==0)
			{
				KPDDR1 = 0x00;
				KPDDR2 = 0x00;
				KPPORT1 = 0xff;
				KPPORT2 = 0xff;
				return (10000*shift+1000+100*sourcePin+10+sinkPin);
			}
		}
		for(sinkPin = KPP2START; sinkPin < (KPP2START + 6); sinkPin++)
		{
			if(((KPPIN2&(1<<sinkPin))>>sinkPin)==0)
			{
				KPDDR1 = 0x00;
				KPDDR2 = 0x00;
				KPPORT1 = 0xff;
				KPPORT2 = 0xff;
				return (10000*shift+1000+100*sourcePin+20+sinkPin);
			}
		}
	}
	for(sourcePin = KPP2START; sourcePin < (KPP2START + 5); sourcePin++)
	{
		KPDDR1 = 0x00;
		KPPORT1 = 0xff;
		KPDDR2 = (1<<sourcePin);
		KPPORT2=~KPDDR2;
		for(sinkPin = sourcePin + 1; sinkPin < (KPP2START + 6); sinkPin++)
		{
			if(((KPPIN2&(1<<sinkPin))>>sinkPin)==0)
			{
				KPDDR1 = 0x00;
				KPDDR2 = 0x00;
				KPPORT1 = 0xff;
				KPPORT2 = 0xff;
				return (10000*shift+2000+100*sourcePin+20+sinkPin);
			}
		}
	}
	KPDDR1 = 0x00;
	KPDDR2 = 0x00;
	KPPORT1 = 0xff;
	KPPORT2 = 0xff;
	return -1;
}

char parsePollResult(int input)
{
	switch(input)
	{
		case 11213: return '-';
		case 11214: return 'z';
		case 11215: return 'd';
		case 11216: return 'r';
		case 11217: return '4';
		case 11222: return '/';
		case 11223: return '.';
		case 11224: return ',';
		case 11225: return '\n';
		case 11226: return 39;
		case 11227: return 59;
		case 11314: return -1;
		case 11315: return 's';
		case 11316: return 'e';
		case 11317: return '3';
		case 11322: return 92;
		case 11323: return ']';
		case 11324: return '[';
		case 11325: return 'u';
		case 11326: return 7;	//backspace
		case 11327: return '=';
		case 11415: return 'a';
		case 11416: return 'w';
		case 11417: return '2';
		case 11422: return 'm';
		case 11423: return 'n';
		case 11424: return 'b';
		case 11425: return 'v';
		case 11426: return 'c';
		case 11427: return 'x';
		case 11516: return 'q';
		case 11517: return '1';
		case 11522: return 'l';
		case 11523: return 'k';
		case 11524: return 'j';
		case 11525: return 'h';
		case 11526: return 'g';
		case 11527: return 'f';
		case 11617: return '`';
		case 11622: return 'p';
		case 11623: return 'o';
		case 11624: return 'i';
		case 11625: return 'u';
		case 11626: return 'y';
		case 11627: return 't';
		case 11722: return '0';
		case 11723: return '9';
		case 11724: return '8';
		case 11725: return '7';
		case 11726: return '6';
		case 11727: return '5';
		case 12223: return 'U';
		case 12224: return 'I';
		case 12225: return 'O';
		case 12226: return 'g';
		case 12227: return 6;	//down
		case 12324: return 'S';
		case 12325: return 'D';
		case 12326: return 'y';
		case 12327: return 5;	//left
		case 12425: return 'H';
		case 12426: return 4;	//right
		case 12427: return ' ';
		case 12526: return 3;	//up
		case 12527: return 1;	//save
		case 12627: return 2;	//load
		case 21213: return '_';
		case 21214: return 'Z';
		case 21215: return 'D';
		case 21216: return 'R';
		case 21217: return '$';
		case 21222: return '?';
		case 21223: return '<';
		case 21224: return '>';
		case 21225: return '\n';
		case 21226: return 34;
		case 21227: return 58;
		case 21314: return -1;
		case 21315: return 'S';
		case 21316: return 'E';
		case 21317: return '#';
		case 21322: return '|';
		case 21323: return '}';
		case 21324: return '{';
		case 21325: return 'U';
		case 21326: return 7;	//backspace
		case 21327: return '+';
		case 21415: return 'A';
		case 21416: return 'W';
		case 21417: return '@';
		case 21422: return 'M';
		case 21423: return 'N';
		case 21424: return 'B';
		case 21425: return 'V';
		case 21426: return 'C';
		case 21427: return 'X';
		case 21516: return 'Q';
		case 21517: return '!';
		case 21522: return 'L';
		case 21523: return 'K';
		case 21524: return 'J';
		case 21525: return 'H';
		case 21526: return 'G';
		case 21527: return 'F';
		case 21617: return '~';
		case 21622: return 'P';
		case 21623: return 'O';
		case 21624: return 'I';
		case 21625: return 'U';
		case 21626: return 'Y';
		case 21627: return 'T';
		case 21722: return ')';
		case 21723: return '(';
		case 21724: return '*';
		case 21725: return '&';
		case 21726: return '^';
		case 21727: return '%';
		case 22223: return 'U';
		case 22224: return 'I';
		case 22225: return 'O';
		case 22226: return 'G';
		case 22227: return 6;	//down
		case 22324: return 'S';
		case 22325: return 'D';
		case 22326: return 'Y';
		case 22327: return 5;	//left
		case 22425: return 'H';
		case 22426: return 4;	//right
		case 22427: return ' ';
		case 22526: return 3;	//up
		case 22527: return 1;	//save
		case 22627: return 2;	//load
		default: return -1;
	}
}

void initializeShift(void)
{
	SHIFTDDR = SHIFTDDR & (~(1<<SHIFTBIT));
	SHIFTPORT = SHIFTPORT | (1<<SHIFTBIT);
}

	
